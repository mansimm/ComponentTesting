package requestType;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;


public class PostTest {

	@Test
	public void postTest() {
		baseURI = "https://reqres.in";
		JSONObject jo = new JSONObject();
		jo.put("name", "Tommy");
		jo.put("job", "Devloper");
		
		System.out.println(jo.toJSONString());
		
		given().accept("application/json").contentType(ContentType.JSON).
		body(jo.toJSONString()).
		when().post("/api/users").
		then().statusCode(201).log().all();
	}
}
