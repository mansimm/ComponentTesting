package auth;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

public class APIKeyAuth {

	@Test
	public void APIKeyAuth() {
		baseURI = "https://api.openweathermap.org";
		String apiKey = "1d99bcce6b4ec5d85ad4144e7627b5dc";
		
		given().accept("application/json").contentType("application/json")
		.queryParam("lat", "44.34")
		.queryParam("lon", "10.99")
		.queryParam("cnt", "2")
		.queryParam("appid", apiKey)
		.when().get("/data/2.5/forecast/daily")
		.then().statusCode(200)
		.log().all();
	}
	//401 means blocked
	
	//api.openweathermap.org/data/2.5/forecast/daily?lat=44.34&lon=10.99&cnt=7&appid={API key}
	@Test
	public void APIKeyAuth_2() {
		baseURI = "https://api.openweathermap.org";
		String apiKey = "1d99bcce6b4ec5d85ad4144e7627b5dc";
		
		given().accept("application/json").contentType("application/json")
		.queryParam("lat", "44.34")
		.queryParam("lon", "10.99")
		.queryParam("cnt", "7")
		.queryParam("appid", apiKey)
		.when().get("/data/2.5/forecast/daily")
		.then().statusCode(200)
		.log().all();
	}
}
