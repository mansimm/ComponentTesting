package auth;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

public class BearerTokenAuth {

	@Test
	public void BearerTokenAuth() {
		baseURI = "https://api.github.com";
		String bearerToken = "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";
		
		given().accept("application/json").contentType("application/json")
		.headers("Authorization", "Bearer "+bearerToken)
		.when().get("/user/repos")
		.then().statusCode(200)
		.log().all();
	}
}
