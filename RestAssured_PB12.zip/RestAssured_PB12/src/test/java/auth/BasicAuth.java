package auth;
import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
public class BasicAuth {

	@Test
	public void basicAuth() {
		baseURI = "https://postman-echo.com";
		given().accept("application/json").contentType("application/json")
		.auth().basic("postman", "password")
		.when().get("/basic-auth")
		.then().statusCode(200)
		.body("authenticated", equalTo(true))
		.log().all();
	}	
}
